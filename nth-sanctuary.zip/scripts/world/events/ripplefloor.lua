local RippleFloor, super = Class(Event)

function RippleFloor:init(data)
    super.init(self, data)
end

return RippleFloor