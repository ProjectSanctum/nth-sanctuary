return {
  version = "1.11",
  luaversion = "5.1",
  tiledversion = "1.11.2",
  name = "fountain_climb",
  class = "",
  tilewidth = 20,
  tileheight = 20,
  spacing = 0,
  margin = 0,
  columns = 13,
  image = "../../../assets/sprites/tilesets/bg_dw_fountain_climb_tileset.png",
  imagewidth = 260,
  imageheight = 220,
  objectalignment = "unspecified",
  tilerendersize = "grid",
  fillmode = "stretch",
  tileoffset = {
    x = 0,
    y = 0
  },
  grid = {
    orientation = "orthogonal",
    width = 20,
    height = 20
  },
  properties = {},
  wangsets = {},
  tilecount = 143,
  tiles = {}
}
