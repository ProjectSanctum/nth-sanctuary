<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bg_dw_church_library_2_tileset" tilewidth="40" tileheight="40" tilecount="260" columns="10">
 <image source="../../../assets/sprites/tilesets/dr ch3-4 fixed tilesets/bg_dw_church_library_2_tileset.png" width="400" height="1040"/>
</tileset>
