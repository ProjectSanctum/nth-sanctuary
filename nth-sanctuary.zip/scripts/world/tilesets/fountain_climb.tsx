<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.11" tiledversion="1.11.2" name="fountain_climb" tilewidth="20" tileheight="20" tilecount="143" columns="13" tilerendersize="grid">
 <image source="../../../assets/sprites/tilesets/bg_dw_fountain_climb_tileset.png" width="260" height="220"/>
</tileset>
