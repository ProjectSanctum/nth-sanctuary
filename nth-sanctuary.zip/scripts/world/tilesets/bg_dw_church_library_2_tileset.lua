return {
  version = "1.10",
  luaversion = "5.1",
  tiledversion = "1.10.2",
  name = "bg_dw_church_library_2_tileset",
  class = "",
  tilewidth = 40,
  tileheight = 40,
  spacing = 0,
  margin = 0,
  columns = 10,
  image = "../../../assets/sprites/tilesets/dr ch3-4 fixed tilesets/bg_dw_church_library_2_tileset.png",
  imagewidth = 400,
  imageheight = 1040,
  objectalignment = "unspecified",
  tilerendersize = "tile",
  fillmode = "stretch",
  tileoffset = {
    x = 0,
    y = 0
  },
  grid = {
    orientation = "orthogonal",
    width = 40,
    height = 40
  },
  properties = {},
  wangsets = {},
  tilecount = 260,
  tiles = {}
}
