<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.11" tiledversion="1.11.2" name="libraryexcerpt" tilewidth="20" tileheight="20" tilecount="48" columns="6" tilerendersize="grid">
 <editorsettings>
  <export target="libraryexcerpt.lua" format="lua"/>
 </editorsettings>
 <image source="../../../assets/sprites/tilesets/libraryexcerpt.png" width="120" height="160"/>
</tileset>
