<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bg_dw_church_tileset_new" tilewidth="40" tileheight="40" tilecount="582" columns="6">
 <image source="../../../assets/sprites/tilesets/dr ch3-4 fixed tilesets/bg_dw_church_tileset_new.png" width="240" height="3880"/>
</tileset>
