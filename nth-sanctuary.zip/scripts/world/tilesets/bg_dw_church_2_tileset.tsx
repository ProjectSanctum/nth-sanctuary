<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.11" tiledversion="1.11.2" name="bg_dw_church_2_tileset" tilewidth="40" tileheight="40" tilecount="198" columns="9">
 <image source="../../../assets/sprites/tilesets/bg_dw_church_2_tileset.png" width="360" height="880"/>
</tileset>
