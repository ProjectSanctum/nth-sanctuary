return {
  version = "1.11",
  luaversion = "5.1",
  tiledversion = "1.11.2",
  name = "libraryexcerpt",
  class = "",
  tilewidth = 20,
  tileheight = 20,
  spacing = 0,
  margin = 0,
  columns = 6,
  image = "../../../assets/sprites/tilesets/libraryexcerpt.png",
  imagewidth = 120,
  imageheight = 160,
  objectalignment = "unspecified",
  tilerendersize = "grid",
  fillmode = "stretch",
  tileoffset = {
    x = 0,
    y = 0
  },
  grid = {
    orientation = "orthogonal",
    width = 20,
    height = 20
  },
  properties = {},
  wangsets = {},
  tilecount = 48,
  tiles = {}
}
