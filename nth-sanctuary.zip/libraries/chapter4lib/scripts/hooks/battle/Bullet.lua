---@class Bullet : Bullet
local Bullet, super = HookSystem.hookScript(Bullet)

return Bullet