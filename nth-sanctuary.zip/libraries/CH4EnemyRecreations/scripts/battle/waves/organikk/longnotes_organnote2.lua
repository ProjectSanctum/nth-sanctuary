local wave, super = Class(Wave)

function wave:init()
    super.init(self)
    self.time = 220/30

    --nooooooooooooooooooooooooooooooone
end

return wave